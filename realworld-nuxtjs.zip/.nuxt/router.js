import Vue from 'vue'
import Router from 'vue-router'
import { normalizeURL, decode } from 'ufo'
import { interopDefault } from './utils'
import scrollBehavior from './router.scrollBehavior.js'

const _56f26aa9 = () => interopDefault(import('..\\pages\\layouts' /* webpackChunkName: "" */))
const _6edfe8bf = () => interopDefault(import('..\\pages\\home' /* webpackChunkName: "" */))
const _6d557789 = () => interopDefault(import('..\\pages\\login' /* webpackChunkName: "" */))
const _46fc89c9 = () => interopDefault(import('..\\pages\\profile' /* webpackChunkName: "" */))
const _29d4c003 = () => interopDefault(import('..\\pages\\settings' /* webpackChunkName: "" */))
const _30cd9d4d = () => interopDefault(import('..\\pages\\editor' /* webpackChunkName: "" */))
const _2dc6cd16 = () => interopDefault(import('..\\pages\\article' /* webpackChunkName: "" */))

const emptyFn = () => {}

Vue.use(Router)

export const routerOptions = {
  mode: 'history',
  base: '/',
  linkActiveClass: 'active',
  linkExactActiveClass: 'nuxt-link-exact-active',
  scrollBehavior,

  routes: [{
    path: "/",
    component: _56f26aa9,
    children: [{
      path: "",
      component: _6edfe8bf,
      name: "home"
    }, {
      path: "/login",
      component: _6d557789,
      name: "login"
    }, {
      path: "/register",
      component: _6d557789,
      name: "register"
    }, {
      path: "/profile/:username",
      component: _46fc89c9,
      name: "profile"
    }, {
      path: "/settings",
      component: _29d4c003,
      name: "settings"
    }, {
      path: "/editor/:slug?",
      component: _30cd9d4d,
      name: "editor"
    }, {
      path: "/article/:slug",
      component: _2dc6cd16,
      name: "article"
    }]
  }],

  fallback: false
}

export function createRouter (ssrContext, config) {
  const base = (config._app && config._app.basePath) || routerOptions.base
  const router = new Router({ ...routerOptions, base  })

  // TODO: remove in Nuxt 3
  const originalPush = router.push
  router.push = function push (location, onComplete = emptyFn, onAbort) {
    return originalPush.call(this, location, onComplete, onAbort)
  }

  const resolve = router.resolve.bind(router)
  router.resolve = (to, current, append) => {
    if (typeof to === 'string') {
      to = normalizeURL(to)
    }
    return resolve(to, current, append)
  }

  return router
}
